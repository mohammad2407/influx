
import './App.css';
import { Exercise } from './Components/Container/Exercise';

function App() {
  return (
    <div className="App">
      hello
     <Exercise />
    </div>
  );
}

export default App;
